import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="Telco Churn Analytics", layout="wide")

st.title("📊 Анализ оттока клиентов телеком-оператора")
st.markdown("Данный интерактивный дашборд разработан для визуализации ключевых факторов оттока и оценки финансового эффекта.")

@st.cache_data
def load_data():
    return pd.read_csv("data/telco_customer_churn.csv")

df = load_data()

# Sidebar filters
st.sidebar.header("Фильтрация данных")
contract_filter = st.sidebar.multiselect("Тип контракта:", options=df["contract_type"].unique(), default=df["contract_type"].unique())
internet_filter = st.sidebar.multiselect("Интернет-провайдер:", options=df["internet_service"].unique(), default=df["internet_service"].unique())

filtered_df = df[(df["contract_type"].isin(contract_filter)) & (df["internet_service"].isin(internet_filter))]

# Metrics
total_customers = len(filtered_df)
churn_rate = (filtered_df["churn"] == "Yes").mean() * 100 if total_customers > 0 else 0
mrr_lost = filtered_df[filtered_df["churn"] == "Yes"]["monthly_charges"].sum() if total_customers > 0 else 0

col1, col2, col3 = st.columns(3)
col1.metric("Всего клиентов в выборке", f"{total_customers:,}")
col2.metric("Уровень оттока (Churn Rate)", f"{churn_rate:.2f}%")
col3.metric("Потерянный MRR (ежемесячно)", f"${mrr_lost:,.2f}")

# Plots
st.subheader("Анализ факторов риска")
fig_col1, fig_col2 = st.columns(2)

with fig_col1:
    fig_contract = px.histogram(filtered_df, x="contract_type", color="churn", barmode="group",
                                title="Отток в разрезе типов контрактов",
                                labels={"contract_type": "Тип контракта", "churn": "Отток"},
                                color_discrete_map={"Yes": "#EF553B", "No": "#636EFA"})
    st.plotly_chart(fig_contract, use_container_width=True)

with fig_col2:
    fig_box = px.box(filtered_df, x="churn", y="tenure_months", color="churn",
                     title="Распределение времени жизни клиента (Tenure) и отток",
                     labels={"churn": "Отток", "tenure_months": "Месяцев в компании"},
                     color_discrete_map={"Yes": "#EF553B", "No": "#636EFA"})
    st.plotly_chart(fig_box, use_container_width=True)

# Business Simulator
st.subheader("🧮 Симулятор снижения оттока (Retention ROI)")
st.markdown("Смоделируйте финансовый эффект от внедрения превентивных кампаний по удержанию пользователей.")

target_reduction = st.slider("Целевое снижение оттока (в % от текущего уровня):", 0, 50, 15)

current_churn_count = (filtered_df["churn"] == "Yes").sum()
saved_customers = int(current_churn_count * (target_reduction / 100))
avg_mrr = filtered_df[filtered_df["churn"] == "Yes"]["monthly_charges"].mean()
saved_revenue_monthly = saved_customers * avg_mrr
saved_revenue_annual = saved_revenue_monthly * 12

sim_col1, sim_col2, sim_col3 = st.columns(3)
sim_col1.metric("Спасенные клиенты", f"{saved_customers} чел.")
sim_col2.metric("Сэкономленный MRR", f"${saved_revenue_monthly:,.2f}")
sim_col3.metric("Дополнительный годовой доход", f"${saved_revenue_annual:,.2f}")
