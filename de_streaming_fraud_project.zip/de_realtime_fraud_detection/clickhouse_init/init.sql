CREATE DATABASE IF NOT EXISTS analytics;

CREATE TABLE IF NOT EXISTS analytics.fct_transactions (
    transaction_id String,
    user_id String,
    amount Float64,
    currency String,
    merchant_category String,
    device_ip String,
    country String,
    event_timestamp DateTime,
    is_fraud UInt8,
    processed_at DateTime DEFAULT now()
) ENGINE = ReplacingMergeTree(processed_at)
PARTITION BY toYYYYMM(event_timestamp)
ORDER BY (country, merchant_category, transaction_id);