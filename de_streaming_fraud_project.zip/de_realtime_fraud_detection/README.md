# 🛡️ Real-time Data Engineering: Система выявления фрод-транзакций в финтехе

Production-ready архитектурный шаблон пайплайна для обработки потоковых данных (Streaming Data Engineering). Проект решает бизнес-задачу обнаружения мошеннических транзакций (Fraud Detection) в реальном времени с использованием **Apache Kafka**, **Python**, **Apache Airflow** и **ClickHouse**.

## 📊 Архитектура и Движение Данных

1. **Генерация событий (Mock API / Microservice):** Python-скрипт эмулирует непрерывный поток финансовых транзакций пользователей и отправляет их в брокер сообщений.
2. **Брокер сообщений (Event Streaming):** Apache Kafka принимает поток сырых JSON-событий в топик `banking_transactions`.
3. **Обработка и Скоринг (Streaming Consumer):** Потоковый Python-потребитель считывает данные из Kafka, в реальном времени применяет базовые правила проверки на фрод (например, превышение лимитов или подозрительные геолокации) и маркирует транзакции флагом `is_fraud`.
4. **Хранилище данных (OLAP DWH):** Данные распределяются и записываются в колоночную СУБД ClickHouse для мгновенной аналитики.
5. **Оркестрация и Мониторинг:** Apache Airflow управляет расписанием сопутствующих регламентных задач (архивация данных, расчет исторических метрик, проверка Data Quality).

```text
[Транзакции] -> [Apache Kafka] -> [Python Consumer (Scoring)] -> [ClickHouse]
                                                                     ^
                                                               [Apache Airflow]
```

## 🛠️ Технологический Стек

* **Инфраструктура:** Docker, Docker Compose
* **Стриминг и брокеры:** Apache Kafka (Zookeeper)
* **Язык разработки:** Python 3.11 (kafka-python, clickhouse-driver)
* **СУБД (DWH):** ClickHouse (Движок `ReplacingMergeTree` для дедупликации)
* **Оркестрация:** Apache Airflow 2.7+

## 🚀 Быстрый запуск

### 1. Подготовка окружения
Клонируйте репозиторий и перейдите в папку проекта. Запустите всю инфраструктуру одной командой:
```bash
docker compose up -d --build
```
*Контейнеры Kafka, ClickHouse и Airflow инициализируются автоматически.*

### 2. Запуск генератора транзакций
Скрипт начнет имитировать активность клиентов интернет-банка и отправлять данные в топик Kafka:
```bash
docker exec -it financial-producer python /app/scripts/transaction_producer.py
```

### 3. Запуск обработчика потока (Fraud Detector)
Стриминговый скрипт начнет считывать сообщения из Kafka, проводить скоринг "на лету" и сохранять результаты в ClickHouse:
```bash
docker exec -it streaming-consumer python /app/scripts/fraud_detector_consumer.py
```

## 📈 Витрина данных в ClickHouse

Для проверки данных подключитесь к ClickHouse (`localhost:8123` или через CLI) и выполните запрос:

```sql
SELECT 
    is_fraud,
    count() as transaction_count,
    avg(amount) as average_amount
FROM analytics.fct_transactions
GROUP BY is_fraud;
```

## 💎 Ценность проекта для портфолио

* **Архитектурный сдвиг в Real-time:** Демонстрирует умение проектировать событийно-ориентированные системы (Event-Driven Architecture), что критически важно для современного уровня Middle/Senior Data Engineer.
* **Идемпотентность и дедупликация:** В ClickHouse настроен движок таблицы `ReplacingMergeTree` по ключу `transaction_id`. Это гарантирует отсутствие дубликатов, если сообщения из Kafka придут повторно при сбоях сети (гарантия доставки At-Least-Once).
* **Эффективный пакетный инсерт:** Пайплайн не грузит ClickHouse построчно (что убивает колоночные базы), а накапливает микро-батчи по 1000 транзакций или по тайм-ауту в 5 секунд.