import json
import time
import random
from datetime import datetime
from kafka import KafkaProducer

def json_serializer(data):
    return json.dumps(data).encode('utf-8')

producer = KafkaProducer(
    bootstrap_servers=['kafka:29092'],
    value_serializer=json_serializer
)

countries = ['RU', 'US', 'GB', 'DE', 'CN', 'CY']
categories = ['electronics', 'groceries', 'apparel', 'gambling', 'airlines']

print("🚀 Запуск генератора транзакций...")

while True:
    is_suspicious = random.random() < 0.05
    amount = round(random.uniform(5000, 200000), 2) if is_suspicious else round(random.uniform(10, 1000), 2)
    
    transaction = {
        "transaction_id": f"tx_{int(time.time() * 1000)}_{random.randint(100, 999)}",
        "user_id": f"usr_{random.randint(1000, 9999)}",
        "amount": amount,
        "currency": "USD",
        "merchant_category": "gambling" if is_suspicious else random.choice(categories),
        "device_ip": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}",
        "country": random.choice(countries),
        "event_timestamp": datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    producer.send('banking_transactions', value=transaction)
    print(f"📡 Отправлена транзакция {transaction['transaction_id']} на сумму ${transaction['amount']}")
    
    time.sleep(random.uniform(0.1, 0.5))