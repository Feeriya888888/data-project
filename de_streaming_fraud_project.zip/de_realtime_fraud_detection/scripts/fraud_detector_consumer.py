import json
from kafka import KafkaConsumer
from clickhouse_driver import Client
from datetime import datetime

consumer = KafkaConsumer(
    'banking_transactions',
    bootstrap_servers=['kafka:29092'],
    value_deserializer=lambda m: json.loads(m.decode('utf-8')),
    auto_offset_reset='latest'
)

ch_client = Client(host='clickhouse', port=9000)

batch = []
BATCH_SIZE = 50

print("📥 Ожидание стриминга транзакций для скоринга...")

for message in consumer:
    tx = message.value
    
    # Бизнес-правило фрода в реальном времени (пример)
    is_fraud = 0
    if tx['amount'] > 50000 or tx['merchant_category'] == 'gambling':
        is_fraud = 1
        print(f"🚨 ФРОД ОБНАРУЖЕН: Транзакция {tx['transaction_id']} помечена как мошенническая!")

    row = (
        tx['transaction_id'],
        tx['user_id'],
        float(tx['amount']),
        tx['currency'],
        tx['merchant_category'],
        tx['device_ip'],
        tx['country'],
        datetime.strptime(tx['event_timestamp'], '%Y-%m-%d %H:%M:%S'),
        int(is_fraud)
    )
    
    batch.append(row)
    
    if len(batch) >= BATCH_SIZE:
        ch_client.execute(
            'INSERT INTO analytics.fct_transactions (transaction_id, user_id, amount, currency, merchant_category, device_ip, country, event_timestamp, is_fraud) VALUES',
            batch
        )
        print(f"💾 Записан микро-батч из {len(batch)} транзакций в ClickHouse.")
        batch = []