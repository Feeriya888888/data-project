import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count, countDistinct, when

if __name__ == "__main__":
    spark = SparkSession.builder \
        .appName("MarketingMetricsCalculation") \
        .config("spark.jars", "/opt/bitnami/spark/jars/postgresql-42.6.0.jar") \
        .getOrCreate()

    # 1. Чтение сырых данных из Data Lake
    df_events = spark.read.json("/opt/bitnami/spark/data/raw_events/*.json")

    # 2. Очистка от ботов (пользователи с аномально высоким количеством кликов за секунду)
    # В данном примере просто базовый фильтр
    df_clean = df_events.filter(col("user_id").isNotNull())

    # 3. Расчет метрик: Визиты, Конверсии в покупки
    mart_df = df_clean.groupBy("event_date", "utm_source").agg(
        countDistinct("user_id").alias("unique_visitors"),
        count(when(col("event_type") == "purchase", 1)).alias("total_purchases")
    )

    # Добавление расчетной метрики Conversion Rate
    mart_df = mart_df.withColumn("conversion_rate", col("total_purchases") / col("unique_visitors"))

    # 4. Запись результатов в PostgreSQL DWH
    mart_df.write \
        .format("jdbc") \
        .option("url", "jdbc:postgresql://postgres_dwh:5432/marketing_dwh") \
        .option("dbtable", "public.mart_marketing_roi") \
        .option("user", "airflow") \
        .option("password", "airflow") \
        .option("driver", "org.postgresql.Driver") \
        .mode("overwrite") \
        .save()

    spark.stop()
