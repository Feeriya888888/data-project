import json
import os
import random
from datetime import datetime
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator

def generate_mock_json():
    os.makedirs('/opt/airflow/data/raw_events', exist_ok=True)
    events = ['view', 'click', 'add_to_cart', 'purchase']
    sources = ['google', 'yandex', 'facebook', 'newsletter']
    
    data = []
    for _ in range(1000):
        data.append({
            "event_date": str(datetime.today().date()),
            "user_id": str(random.randint(10000, 99999)),
            "event_type": random.choice(events),
            "utm_source": random.choice(sources)
        })
        
    file_path = f'/opt/airflow/data/raw_events/events_{datetime.today().strftime("%Y%m%d")}.json'
    with open(file_path, 'w') as f:
        for item in data:
            f.write(json.dumps(item) + '\n')

with DAG(
    'marketing_spark_pipeline',
    start_date=datetime(2026, 1, 1),
    schedule_interval='@daily',
    catchup=False
) as dag:

    generate_data = PythonOperator(
        task_id='generate_lake_data',
        python_callable=generate_mock_json
    )

    spark_transform = SparkSubmitOperator(
        task_id='pyspark_process_metrics',
        application='/opt/airflow/jobs/marketing_roi.py',
        conn_id='spark_default',
        total_executor_cores='1',
        executor_memory='1g'
    )

    generate_data >> spark_transform
