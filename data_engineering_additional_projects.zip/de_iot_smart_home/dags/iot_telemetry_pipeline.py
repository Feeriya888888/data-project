from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.generic_transfer import GenericTransfer
from clickhouse_driver import Client

default_args = {
    'owner': 'data_engineer',
    'start_date': datetime(2026, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

def run_analytics():
    client = Client(host='clickhouse', port=9000)
    
    # Идемпотентный расчет витрины
    calc_query = """
        INSERT INTO smart_home.mart_daily_device_stats
        SELECT 
            toDate(timestamp) as event_date,
            device_id,
            metric_name,
            avg(metric_value) as avg_value,
            max(metric_value) as max_value,
            min(metric_value) as min_value,
            count() as total_records
        FROM smart_home.raw_telemetry
        WHERE toDate(timestamp) = today()
        GROUP BY event_date, device_id, metric_name
    """
    client.execute(calc_query)
    print("Витрина успешно обновлена.")

with DAG(
    'iot_telemetry_pipeline',
    default_args=default_args,
    schedule_interval='@daily',
    catchup=False
) as dag:

    extract_and_load = PythonOperator(
        task_id='extract_sensor_data',
        python_callable=lambda: __import__('scripts.extract_api').extract_api.generate_and_load_data()
    )

    transform_data = PythonOperator(
        task_id='aggregate_to_marts',
        python_callable=run_analytics
    )

    extract_and_load >> transform_data
