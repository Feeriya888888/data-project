import uuid
import random
from datetime import datetime, timedelta
from clickhouse_driver import Client

def generate_and_load_data():
    client = Client(host='clickhouse', port=9000)
    
    # Генерация синтетических данных с датчиков
    metrics = ['temperature', 'humidity', 'power_consumption']
    devices = [uuid.uuid4() for _ in range(5)]
    
    data = []
    now = datetime.utcnow()
    
    for device in devices:
        for _ in range(100): # 100 логов на устройство
            ts = now - timedelta(minutes=random.randint(1, 1440))
            metric = random.choice(metrics)
            
            if metric == 'temperature':
                val = random.uniform(18.0, 26.0)
            elif metric == 'humidity':
                val = random.uniform(30.0, 60.0)
            else:
                val = random.uniform(0.1, 3.5)
                
            data.append({
                'device_id': device,
                'timestamp': ts,
                'metric_name': metric,
                'metric_value': val
            })
            
    client.execute(
        'INSERT INTO smart_home.raw_telemetry (device_id, timestamp, metric_name, metric_value) VALUES',
        data
    )
    print(f"Успешно загружено {len(data)} записей в ClickHouse raw слой.")

if __name__ == "__main__":
    generate_and_load_data()
