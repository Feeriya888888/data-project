CREATE DATABASE IF NOT EXISTS smart_home;

CREATE TABLE IF NOT EXISTS smart_home.raw_telemetry (
    device_id UUID,
    timestamp DateTime,
    metric_name String,
    metric_value Float64
) ENGINE = MergeTree()
ORDER BY (metric_name, timestamp);

CREATE TABLE IF NOT EXISTS smart_home.mart_daily_device_stats (
    event_date Date,
    device_id UUID,
    metric_name String,
    avg_value Float64,
    max_value Float64,
    min_value Float64,
    total_records UInt32
) ENGINE = SummingMergeTree()
ORDER BY (event_date, device_id, metric_name);
