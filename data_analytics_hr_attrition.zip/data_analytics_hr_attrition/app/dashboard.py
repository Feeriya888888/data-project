import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title="HR Analytics Dashboard", layout="wide")

@st.cache_data
def load_data():
    return pd.read_csv("data/hr_employee_attrition.csv")

df = load_data()

st.title("📊 HR Analytics: Анализ оттока персонала и оценка стоимости потерь")
st.markdown("---")

# KPIs
total_employees = len(df)
attrition_rate = (df['attrition'].sum() / total_employees) * 100
avg_income = df['monthly_income_usd'].mean()

col1, col2, col3 = st.columns(3)
col1.metric("Всего сотрудников в базе", f"{total_employees} чел.")
col2.metric("Уровень текучести (Attrition Rate)", f"{attrition_rate:.1f}%")
col3.metric("Средний доналоговый доход", f"${avg_income:,.0f}")

st.markdown("### 🔍 Факторы влияния на увольнение")
tab1, tab2 = st.tabs(["Баланс работы/жизни", "Доход сотрудника"])

with tab1:
    fig_wlb = px.histogram(df, x="work_life_balance", color="attrition", barmode="group",
                           title="Распределение увольнений по уровню Work-Life Balance (1-Плохо, 4-Отлично)",
                           labels={"work_life_balance": "Уровень баланса", "count": "Количество сотрудников"})
    st.plotly_chart(fig_wlb, use_container_width=True)

with tab2:
    fig_inc = px.box(df, x="attrition", y="monthly_income_usd", color="attrition",
                     title="Зависимость уровня дохода от факта ухода сотрудника",
                     labels={"attrition": "Уволился (1 - Да, 0 - Нет)", "monthly_income_usd": "Ежемесячный доход ($)"})
    st.plotly_chart(fig_inc, use_container_width=True)

st.markdown("---")
st.markdown("### 💰 Бизнес-симулятор: ROI программ удержания персонала")

col_sim1, col_sim2 = st.columns(2)
with col_sim1:
    st.markdown("#### Параметры модели затрат")
    cost_to_replace = st.slider("Стоимость замены 1 сотрудника (окладов)", 3, 12, 6)
    retention_efficiency = st.slider("Эффективность программы удержания (%)", 10, 80, 30)

with col_sim2:
    st.markdown("#### Расчет финансового эффекта")
    current_losses = int(df['attrition'].sum())
    avg_salary_loss = df[df['attrition'] == 1]['monthly_income_usd'].mean()
    
    total_cost_before = current_losses * avg_salary_loss * cost_to_replace
    saved_employees = int(current_losses * (retention_efficiency / 100))
    financial_savings = saved_employees * avg_salary_loss * cost_to_replace
    
    st.error(f"Текущие прямые потери бизнеса от оттока: **${total_cost_before:,.0f}**")
    st.success(f"Будет спасено сотрудников: **{saved_employees} чел.**")
    st.info(f"Сэкономленный бюджет компании за счет оптимизации: **${financial_savings:,.0f}**")
