# Разведочный анализ данных HR
# В реальном файле будет JSON структура .ipynb
import pandas as pd
import scipy.stats as stats

df = pd.read_csv('../data/hr_employee_attrition.csv')

# Проверка гипотезы: Отличается ли доход ушедших и оставшихся сотрудников?
group_stayed = df[df['attrition'] == 0]['monthly_income_usd']
group_left = df[df['attrition'] == 1]['monthly_income_usd']

t_stat, p_val = stats.ttest_ind(group_stayed, group_left, equal_var=False)
print(f"T-statistic: {t_stat}, P-value: {p_val}")
