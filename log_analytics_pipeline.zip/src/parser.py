import re
from datetime import datetime

# Регулярное выражение для стандартного Combined Log Format (Nginx/Apache)
LOG_PATTERN = r'^(\S+) \S+ \S+ \[([^\]]+)\] "(\S+) (\S+)\s*[^"]*" (\d+) (\d+) "[^"]*" "[^"]*"'

def parse_log_line(line: str) -> dict:
    """
    Парсит одну строку лога. Возвращает словарь с данными или None, если строка некорректна.
    """
    match = re.match(LOG_PATTERN, line)
    if not match:
        return None
        
    ip, timestamp_str, method, path, status, bytes_sent = match.groups()
    
    try:
        # Пример формата: 10/Oct/2026:13:55:36 +0000
        # Для простоты усечем до секунд без таймзоны
        dt = datetime.strptime(timestamp_str.split(' ')[0], "%d/%b/%Y:%H:%M:%S")
        
        return {
            "ip_address": ip,
            "timestamp": dt,
            "http_method": method,
            "request_path": path,
            "http_status": int(status),
            "body_bytes_sent": int(bytes_sent)
        }
    except Exception:
        return None