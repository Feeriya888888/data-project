import os
import time
import psycopg2
from parser import parse_log_line
from db_loader import load_data_to_silver

# Фейковые тестовые логи для демонстрации работы
MOCK_LOGS = [
    '192.168.1.1 - - [12/Oct/2026:14:01:10 +0300] "GET /api/v1/products HTTP/1.1" 200 1024 "-" "Mozilla/5.0"',
    '192.168.1.5 - - [12/Oct/2026:14:02:15 +0300] "POST /api/v1/checkout HTTP/1.1" 400 256 "-" "Mozilla/5.0"',
    '10.0.0.12 - - [12/Oct/2026:15:10:00 +0300] "GET /index.html HTTP/1.1" 200 5112 "-" "Mozilla/5.0"',
    'MALFORMED LINE COMPROMISED LOG ATTACK TIME!!!',
    '192.168.1.5 - - [12/Oct/2026:15:11:45 +0300] "GET /api/v1/products HTTP/1.1" 500 128 "-" "Mozilla/5.0"'
]

def main():
    print("Запуск пайплайна обработки логов...")
    db_host = os.getenv("DB_HOST", "localhost")
    db_name = os.getenv("DB_NAME", "postgres")
    db_user = os.getenv("DB_USER", "postgres")
    db_password = os.getenv("DB_PASSWORD", "postgres")

    # Ожидание инициализации базы данных
    time.sleep(3)

    conn = psycopg2.connect(
        host=db_host, database=db_name, user=db_user, password=db_password
    )
    
    parsed_records = []
    malformed_count = 0
    
    for line in MOCK_LOGS:
        parsed = parse_log_line(line)
        if parsed:
            parsed_records.append(parsed)
        else:
            malformed_count += 1

    print(f"Успешно распарсено записей: {len(parsed_records)}")
    print(f"Пропущено некорректных строк (Data Quality Check): {malformed_count}")

    if parsed_records:
        load_data_to_silver(conn, parsed_records)
        print("Данные успешно загружены в слой Silver PostgreSQL!")
        
    conn.close()
    print("Пайплайн успешно завершил работу.")

if __name__ == "__main__":
    main()