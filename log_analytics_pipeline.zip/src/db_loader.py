import psycopg2
from psycopg2.extras import execute_batch

def load_data_to_silver(conn, data_list: list):
    """
    Пакетная вставка записей в таблицу слоя Silver
    """
    query = """
        INSERT INTO silver_web_logs (ip_address, timestamp, http_method, request_path, http_status, body_bytes_sent)
        VALUES (%(ip_address)s, %(timestamp)s, %(http_method)s, %(request_path)s, %(http_status)s, %(body_bytes_sent)s);
    """
    with conn.cursor() as cursor:
        execute_batch(cursor, query, data_list)
    conn.commit()