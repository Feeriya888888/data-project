from src.parser import parse_log_line
from datetime import datetime

def test_parse_valid_line():
    valid_line = '192.168.1.1 - - [12/Oct/2026:14:01:10 +0300] "GET /api/v1/products HTTP/1.1" 200 1024 "-" "Mozilla"'
    result = parse_log_line(valid_line)
    
    assert result is not None
    assert result["ip_address"] == "192.168.1.1"
    assert result["http_method"] == "GET"
    assert result["http_status"] == 200
    assert result["body_bytes_sent"] == 1024
    assert isinstance(result["timestamp"], datetime)

def test_parse_invalid_line():
    invalid_line = 'Some random trash line that does not look like log at all'
    result = parse_log_line(invalid_line)
    assert result is None