-- 1. Заполнение витрины данных почасовыми метриками
INSERT INTO gold_hourly_traffic_metrics (metric_hour, total_requests, error_4xx_5xx_count, total_bytes_transferred)
SELECT 
    DATE_TRUNC('hour', timestamp) AS metric_hour,
    COUNT(*) AS total_requests,
    COUNT(CASE WHEN http_status >= 400 THEN 1 END) AS error_4xx_5xx_count,
    SUM(body_bytes_sent) AS total_bytes_transferred
FROM silver_web_logs
GROUP BY DATE_TRUNC('hour', timestamp)
ON CONFLICT (metric_hour) DO UPDATE SET
    total_requests = EXCLUDED.total_requests,
    error_4xx_5xx_count = EXCLUDED.error_4xx_5xx_count,
    total_bytes_transferred = EXCLUDED.total_bytes_transferred;

-- 2. Топ-10 самых активных подозрительных IP-адресов (много ошибок)
SELECT 
    ip_address,
    COUNT(*) AS total_errors
FROM silver_web_logs
WHERE http_status >= 400
GROUP BY ip_address
ORDER BY total_errors DESC
LIMIT 10;