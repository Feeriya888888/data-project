-- Слой очищенных данных (Silver Layer)
CREATE TABLE IF NOT EXISTS silver_web_logs (
    id SERIAL PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL,
    timestamp TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    http_method VARCHAR(10) NOT NULL,
    request_path TEXT NOT NULL,
    http_status INTEGER NOT NULL,
    body_bytes_sent INTEGER NOT NULL,
    user_agent TEXT,
    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Индексы для оптимизации аналитических запросов
CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON silver_web_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_logs_status ON silver_web_logs(http_status);

-- Витрина данных: Агрегаты по часам (Gold Layer)
CREATE TABLE IF NOT EXISTS gold_hourly_traffic_metrics (
    metric_hour TIMESTAMP PRIMARY KEY,
    total_requests BIGINT NOT NULL,
    error_4xx_5xx_count BIGINT NOT NULL,
    total_bytes_transferred BIGINT NOT NULL
);