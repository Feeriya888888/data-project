-- Создание слоев архитектуры данных
CREATE SCHEMA IF NOT EXISTS raw;
CREATE SCHEMA IF NOT EXISTS staging;
CREATE SCHEMA IF NOT EXISTS analytics;

-- Создание таблицы для сырых транзакционных данных
CREATE TABLE IF NOT EXISTS raw.orders (
    order_id VARCHAR(50),
    user_id VARCHAR(50),
    order_date VARCHAR(50),
    product_name VARCHAR(100),
    price VARCHAR(50),
    quantity VARCHAR(50),
    status VARCHAR(30)
);
