import pandas as pd
import psycopg2
from datetime import datetime, timedelta
import random

def generate_mock_data():
    print("Генерация фейковых транзакций интернет-магазина...")
    products = {
        "Слуховые аппараты / Наушники Pro": 15000,
        "Смартфон Сhrono X": 65000,
        "Умные часы FitTrack": 85000,
        "Беспроводная зарядка AirCharge": 3500
    }
    
    data = []
    base_date = datetime.now() - timedelta(days=1)
    
    for i in range(100):
        prod, price = random.choice(list(products.items()))
        qty = random.randint(1, 3)
        status = random.choices(["accepted", "canceled", "refunded"], weights=[85, 10, 5])[0]
        
        data.append({
            "order_id": f"ORD-{base_date.strftime('%Y%m%d')}-{i:04d}",
            "user_id": f"USR-{random.randint(1000, 9999)}",
            "order_date": base_date.strftime("%Y-%m-%d %H:%M:%S"),
            "product_name": prod,
            "price": str(price),
            "quantity": str(qty),
            "status": status
        })
    return pd.DataFrame(data)

def load_to_postgres():
    df = generate_mock_data()
    
    conn = psycopg2.connect(
        host="postgres",
        database="warehouse",
        user="airflow",
        password="airflow"
    )
    cursor = conn.cursor()
    
    # Очистка старых сырых данных перед новой загрузкой (идемпотентность)
    cursor.execute("TRUNCATE TABLE raw.orders;")
    
    # Запись в БД
    for _, row in df.iterrows():
        cursor.execute(
            """
            INSERT INTO raw.orders (order_id, user_id, order_date, product_name, price, quantity, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """,
            (row['order_id'], row['user_id'], row['order_date'], row['product_name'], row['price'], row['quantity'], row['status'])
        )
    
    conn.commit()
    cursor.close()
    conn.close()
    print(f"Успешно загружено {len(df)} строк в слой raw.orders")

if __name__ == "__main__":
    load_to_postgres()
