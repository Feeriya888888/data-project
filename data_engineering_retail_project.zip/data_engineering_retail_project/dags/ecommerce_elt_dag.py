from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.python_operator import PythonOperator
import sys
sys.path.append('/usr/local/airflow')
from scripts.extract_api import load_to_postgres

default_args = {
    'owner': 'data_engineer',
    'depends_on_past': False,
    'start_date': datetime(2026, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'retail_ecommerce_elt_pipeline',
    default_args=default_args,
    description='Конвейер загрузки и трансформации данных онлайн ритейла',
    schedule_interval='@daily',
    catchup=False
)

task_extract_load = PythonOperator(
    task_id='extract_and_load_raw',
    python_callable=load_to_postgres,
    dag=dag,
)

task_dbt_run = BashOperator(
    task_id='dbt_run_transformations',
    bash_command='cd /usr/local/airflow/dbt_project && dbt run',
    dag=dag,
)

task_dbt_test = BashOperator(
    task_id='dbt_data_quality_tests',
    bash_command='cd /usr/local/airflow/dbt_project && dbt test',
    dag=dag,
)

task_extract_load >> task_dbt_run >> task_dbt_test
