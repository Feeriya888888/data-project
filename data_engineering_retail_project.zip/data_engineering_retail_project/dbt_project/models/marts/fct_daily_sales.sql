-- Витрина расчета ключевых бизнес-метрик по дням и товарам
with staging_orders as (
    select * from {{ ref('stg_orders') }}
)

select
    cast(order_timestamp as date) as sales_date,
    product_name,
    count(distinct order_id) as total_orders,
    sum(item_quantity) as total_items_sold,
    sum(unit_price * item_quantity) as gross_revenue,
    sum(case when status = 'accepted' then unit_price * item_quantity else 0 end) as net_revenue
from staging_orders
group by 1, 2
order by sales_date desc, net_revenue desc
