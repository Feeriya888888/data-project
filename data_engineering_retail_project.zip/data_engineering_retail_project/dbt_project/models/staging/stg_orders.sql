-- Очистка и кастинг типов для транзакций
with raw_source as (
    select * from {{ source('raw_ecommerce', 'orders') }}
)

select
    order_id,
    user_id,
    cast(order_date as timestamp) as order_timestamp,
    product_name,
    cast(price as numeric) as unit_price,
    cast(quantity as integer) as item_quantity,
    status
from raw_source
where order_id is not null
