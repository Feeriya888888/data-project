import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="SaaS Churn Analytics", layout="wide")

st.title("📊 Аналитика оттока пользователей SaaS платформы")
st.markdown("Данный дашборд визуализирует метрики удержания и финансовые потери от оттока.")

# Загрузка данных
@st.cache_data
def load_data():
    return pd.read_csv("data/saas_user_activity.csv")

try:
    df = load_data()
except:
    df = pd.DataFrame({
        'user_id': [1,2,3,4],
        'activity_score': [85, 20, 92, 15],
        'churned': [0, 1, 0, 1],
        'monthly_spend': [49, 49, 99, 49],
        'channel': ['Organic', 'Paid Ads', 'Referral', 'Paid Ads']
    })

# Фильтры
channel_filter = st.sidebar.multiselect("Канал привлечения", df['channel'].unique(), default=df['channel'].unique())
filtered_df = df[df['channel'].isin(channel_filter)]

# Метрики верхнего уровня
col1, col2, col3 = st.columns(3)
total_users = len(filtered_df)
churn_rate = (filtered_df['churned'].sum() / total_users) * 100
total_mrr_lost = filtered_df[filtered_df['churned'] == 1]['monthly_spend'].sum()

col1.metric("Всего пользователей в выборке", f"{total_users} чел.")
col2.metric("Текущий Churn Rate", f"{churn_rate:.1f}%")
col3.metric("Потери MRR (отток)", f"${total_mrr_lost} / мес")

# Графики
st.subheader("Распределение активности ушедших и активных клиентов")
fig = px.box(filtered_df, x="churned", y="activity_score", color="churned",
             labels={"churned": "Ушел (1) / Активен (0)", "activity_score": "Индекс активности"},
             title="Активность пользователей")
st.plotly_chart(fig, use_container_width=True)

st.sidebar.markdown("---")
st.sidebar.markdown("**Инструмент симуляции удержания**")
reduction = st.sidebar.slider("Снижение оттока на (%)", 0, 50, 10)
saved_money = total_mrr_lost * (reduction / 100) * 12
st.sidebar.info(f"Экономия бюджета при оптимизации: **${saved_money:.2f} в год**")
